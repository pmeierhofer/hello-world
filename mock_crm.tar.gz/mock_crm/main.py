import datetime
import random
from wsgiref.simple_server import make_server

from faker import Faker
from wsgiservice import Resource, get_app, mount, raise_400, validate

# How many fake accounts to create
ACCOUNT_COUNT = 1000

# How many fake notes to create
NOTE_COUNT = 5000

# At which date to start the call notes
START_DATE = datetime.datetime(2005, 1, 1)


@mount("/")
class Home(Resource):
    EXTENSION_MAP = [(".html", "text/html")]

    def GET(self):
        return """
<p>Welcome to the Fake CRM.</p>
<p>This CRM will return a list of companies on <a href="/accounts">/accounts</a>. The resource accepts pagination with the parameters `count=` and `start=`, for example: <a href="/accounts?count=10&amp;start=20">/accounts?count=10&amp;start=20</a>.</p>
<p>An individual account can be accessed at <tt>/accounts/&lt;id&gt;</tt>, for example <a href="/accounts/1">/accounts/1</a>.</p>

<p>For call notes the same pattern is available. All call notes are on <a href="/notes">/notes</a>. Again the resource accepts pagination with the parameters `count=` and `start=`, for example: <a href="/notes?count=15&amp;start=5">/notes?count=15&amp;start=5</a>.</p>
<p>The notes can also be queried on creation date by adding <tt>after=&lt;datetime&gt;</tt>. For example: <a href="/notes?after=2019-01-02 10:00:00">/notes?after=2019-01-02 10:00:00</a> will query all notes created after 10am on January 2, 2019.</p>
<p>An individual note can be accessed at <tt>/notes/&lt;id&gt;</tt>, for example <a href="/notes/102">/notes/102</a>.</p>
"""

    def to_text_html(self, raw):
        return raw


class ListResource(Resource):
    EXTENSION_MAP = [(".json", "application/json")]

    @validate("count", convert=int)
    @validate("start", convert=int)
    def GET(self, start=0, count=10, after=None):
        if start < 0:
            raise_400(self, "Invalid start - must be positive number")

        if count > 50 or count < 1:
            raise_400(self, "Invalid count - use value from 1 to 50")

        data = self._get_data()
        if start >= len(data):
            raise_400(self, "Invalid start - can not navigate beyond last result")

        if after:
            data = [d for d in data if d["date"] > after]

        ret_data = data[start : count + start]
        return {
            "total_count": len(data),
            "start": start,
            "count": count,
            "items": ret_data,
            "eof": count + start >= len(data),
        }

    def _get_data(self):
        raise NotImplementedError("_get_data needs to be implemented in subclasses.")


class DetailResource(Resource):
    EXTENSION_MAP = [(".json", "application/json")]
    NOT_FOUND = (IndexError,)

    @validate("id", convert=int)
    def GET(self, id):
        if id < 0:
            raise_400(self, "invalid id")

        data = self._get_data()
        return data[id]

    def _get_data(self):
        raise NotImplementedError("_get_data needs to be implemented in subclasses.")


@mount("/accounts")
class Accounts(ListResource):
    def _get_data(self):
        return app.accounts


@mount("/accounts/{id}")
class AccountDetail(DetailResource):
    def _get_data(self):
        return app.accounts


@mount("/notes")
class Notes(ListResource):
    def _get_data(self):
        return app.notes


@mount("/notes/{id}")
class NoteDetail(DetailResource):
    def _get_data(self):
        return app.notes


app = get_app(globals())


# Generate fake data
def generate_accounts():
    fake = Faker()
    Faker.seed(2009)

    ret = []
    for i in range(ACCOUNT_COUNT):
        ret.append(
            {
                "id": i,
                "name": fake.company(),
                "description": fake.catch_phrase(),
                "ceo": fake.name(),
                "phone": fake.phone_number(),
                "address": fake.address(),
            }
        )
    return ret


def generate_notes(accounts):
    fake = Faker()
    Faker.seed(2010)

    ret = []
    for i in range(NOTE_COUNT):
        account = random.choice(accounts)

        dt = START_DATE + datetime.timedelta(seconds=i * 86400)
        time = fake.date_time()
        dt = dt.replace(hour=time.hour, minute=time.minute, second=time.minute)

        ret.append(
            {
                "id": i,
                "account_id": account["id"],
                "contact": fake.name(),
                "content": "\n".join(fake.paragraphs()),
                "date": dt.strftime("%Y-%m-%d %H:%M:%S"),
            }
        )

    ret.sort(key=lambda i: i["date"])
    return ret


print("Generating fake data - this may take a moment")

app.accounts = generate_accounts()
app.notes = generate_notes(app.accounts)


if __name__ == "__main__":
    print("Running on port 5001")
    print("Access on http://localhost:5001/")
    make_server("", 5001, app).serve_forever()
