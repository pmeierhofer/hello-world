This is a fake CRM system used for Squirro development certifications.

## Setup

To run this service, follow these steps (assuming Mac/Linux, Windows is subtly
different):

1. Create a new virtual environment - both Python 2.7 and 3 are supported:
   `virtualenv .env -p python3`
2. Activate the virtual environment:
   `source .env/bin/activate`
3. Install the dependencies:
   `pip install -r requirements.txt`
4. Run the service:
   `python main.py`

This installation can also be done on a Squirro box, in which case it is done
as follows (all commands executed as root):

1. Activate the Squirro environment
   `squirro_activate3`
2. Install the dependencies:
   `pip install -r requirements.txt`
3. Run the service:
   `python main.py`

The service will run on port 5001 - you can access
http://localhost:5001/_internal/help to see an intro page.
